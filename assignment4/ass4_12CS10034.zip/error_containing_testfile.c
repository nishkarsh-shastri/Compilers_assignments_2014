int main(int argc, char const *argv[])
{
	CLeafaflk;
	afjll;
	int s = int b;
	
	return 0;
}
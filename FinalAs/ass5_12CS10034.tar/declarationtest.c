//function declaration

double function(int a,int b);
//main function

int main()
{
	int x;
	int y;
	int a,b;
	double val1,val2;
	char char_val1;
	int *p;
	double *q;
	char *char_pointer,d;
	int f = 4;
	double dbl = 4.5;
	int array[100];
	double array_2d[24][34],consec;
	int **k;
}

double function(int a,int b)
{
	int x;
	char c = 'f';
	double y=x;
	return y;
}

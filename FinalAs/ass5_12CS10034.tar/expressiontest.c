//The following code will check whether general expressions
//are handled well or not.
//main function declaration
int main()
{
	int a,b,h;
	double e,f,g;
	int temp = 1;
	char c;
	double array[20];
	array[12] = a;
	h = array[9];
	int array_2d[30][40];
	h = array_2d[3][4];
	array_2d[4][5] = e;
	c = 'a';
	a = 10;
	b = 20;
	f = 12;
	g = 1.0;
	while(a<b)
	{
		c = f+g;
	}
	a = f*b;
	b = c*g;
	temp = e/f;
	c = a-b;
	if(a<b && e>=f)
	{
		temp = f+h;
	}
	else
	{
		temp = f;
	}
	int x;
	x = a<b;
	int y;
	y = (a<b) + e;
	a = (-b*f)/(e/f-g);

	x = (double)c;
}
